﻿namespace Sunny.UI.Demo
{
    partial class FButton
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.uiButton1 = new Sunny.UI.UIButton();
            this.uiButton2 = new Sunny.UI.UIButton();
            this.uiButton3 = new Sunny.UI.UIButton();
            this.uiButton4 = new Sunny.UI.UIButton();
            this.uiButton5 = new Sunny.UI.UIButton();
            this.uiButton6 = new Sunny.UI.UIButton();
            this.uiButton7 = new Sunny.UI.UIButton();
            this.uiButton8 = new Sunny.UI.UIButton();
            this.uiButton9 = new Sunny.UI.UIButton();
            this.uiButton10 = new Sunny.UI.UIButton();
            this.uiButton11 = new Sunny.UI.UIButton();
            this.uiButton12 = new Sunny.UI.UIButton();
            this.uiButton13 = new Sunny.UI.UIButton();
            this.uiButton14 = new Sunny.UI.UIButton();
            this.uiButton15 = new Sunny.UI.UIButton();
            this.uiButton16 = new Sunny.UI.UIButton();
            this.uiButton17 = new Sunny.UI.UIButton();
            this.uiButton18 = new Sunny.UI.UIButton();
            this.uiLine1 = new Sunny.UI.UILine();
            this.uiLine2 = new Sunny.UI.UILine();
            this.uiSymbolButton3 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton4 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton5 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton6 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton7 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton8 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton9 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton10 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton11 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton12 = new Sunny.UI.UISymbolButton();
            this.uiLine3 = new Sunny.UI.UILine();
            this.uiSymbolButton13 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton14 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton15 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton16 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton17 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton18 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton19 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton20 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton21 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton22 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton23 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton24 = new Sunny.UI.UISymbolButton();
            this.uiSwitch1 = new Sunny.UI.UISwitch();
            this.uiLine4 = new Sunny.UI.UILine();
            this.uiSwitch2 = new Sunny.UI.UISwitch();
            this.uiLine5 = new Sunny.UI.UILine();
            this.uiToolTip1 = new Sunny.UI.UIToolTip(this.components);
            this.uiSymbolButton1 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton2 = new Sunny.UI.UISymbolButton();
            this.uiSymbolButton25 = new Sunny.UI.UISymbolButton();
            this.uiImageButton4 = new Sunny.UI.UIImageButton();
            this.uiImageButton3 = new Sunny.UI.UIImageButton();
            this.uiImageButton2 = new Sunny.UI.UIImageButton();
            this.uiImageButton1 = new Sunny.UI.UIImageButton();
            this.uiSymbolButton26 = new Sunny.UI.UISymbolButton();
            this.PagePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.uiImageButton4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiImageButton3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiImageButton2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiImageButton1)).BeginInit();
            this.SuspendLayout();
            // 
            // PagePanel
            // 
            this.PagePanel.Controls.Add(this.uiSymbolButton26);
            this.PagePanel.Controls.Add(this.uiSymbolButton25);
            this.PagePanel.Controls.Add(this.uiImageButton4);
            this.PagePanel.Controls.Add(this.uiImageButton3);
            this.PagePanel.Controls.Add(this.uiImageButton2);
            this.PagePanel.Controls.Add(this.uiImageButton1);
            this.PagePanel.Controls.Add(this.uiLine5);
            this.PagePanel.Controls.Add(this.uiSwitch2);
            this.PagePanel.Controls.Add(this.uiLine4);
            this.PagePanel.Controls.Add(this.uiSwitch1);
            this.PagePanel.Controls.Add(this.uiSymbolButton24);
            this.PagePanel.Controls.Add(this.uiSymbolButton23);
            this.PagePanel.Controls.Add(this.uiSymbolButton22);
            this.PagePanel.Controls.Add(this.uiSymbolButton19);
            this.PagePanel.Controls.Add(this.uiSymbolButton20);
            this.PagePanel.Controls.Add(this.uiSymbolButton21);
            this.PagePanel.Controls.Add(this.uiSymbolButton13);
            this.PagePanel.Controls.Add(this.uiSymbolButton14);
            this.PagePanel.Controls.Add(this.uiSymbolButton15);
            this.PagePanel.Controls.Add(this.uiSymbolButton16);
            this.PagePanel.Controls.Add(this.uiSymbolButton17);
            this.PagePanel.Controls.Add(this.uiSymbolButton18);
            this.PagePanel.Controls.Add(this.uiLine3);
            this.PagePanel.Controls.Add(this.uiSymbolButton7);
            this.PagePanel.Controls.Add(this.uiSymbolButton8);
            this.PagePanel.Controls.Add(this.uiSymbolButton9);
            this.PagePanel.Controls.Add(this.uiSymbolButton10);
            this.PagePanel.Controls.Add(this.uiSymbolButton11);
            this.PagePanel.Controls.Add(this.uiSymbolButton12);
            this.PagePanel.Controls.Add(this.uiSymbolButton6);
            this.PagePanel.Controls.Add(this.uiSymbolButton5);
            this.PagePanel.Controls.Add(this.uiSymbolButton3);
            this.PagePanel.Controls.Add(this.uiSymbolButton4);
            this.PagePanel.Controls.Add(this.uiSymbolButton2);
            this.PagePanel.Controls.Add(this.uiSymbolButton1);
            this.PagePanel.Controls.Add(this.uiLine2);
            this.PagePanel.Controls.Add(this.uiLine1);
            this.PagePanel.Controls.Add(this.uiButton13);
            this.PagePanel.Controls.Add(this.uiButton14);
            this.PagePanel.Controls.Add(this.uiButton15);
            this.PagePanel.Controls.Add(this.uiButton16);
            this.PagePanel.Controls.Add(this.uiButton17);
            this.PagePanel.Controls.Add(this.uiButton18);
            this.PagePanel.Controls.Add(this.uiButton7);
            this.PagePanel.Controls.Add(this.uiButton8);
            this.PagePanel.Controls.Add(this.uiButton9);
            this.PagePanel.Controls.Add(this.uiButton10);
            this.PagePanel.Controls.Add(this.uiButton11);
            this.PagePanel.Controls.Add(this.uiButton12);
            this.PagePanel.Controls.Add(this.uiButton4);
            this.PagePanel.Controls.Add(this.uiButton5);
            this.PagePanel.Controls.Add(this.uiButton6);
            this.PagePanel.Controls.Add(this.uiButton3);
            this.PagePanel.Controls.Add(this.uiButton2);
            this.PagePanel.Controls.Add(this.uiButton1);
            this.PagePanel.Size = new System.Drawing.Size(800, 499);
            this.PagePanel.Text = "";
            // 
            // uiButton1
            // 
            this.uiButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton1.FillColor = System.Drawing.Color.White;
            this.uiButton1.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.uiButton1.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.uiButton1.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.uiButton1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiButton1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(98)))), ((int)(((byte)(102)))));
            this.uiButton1.ForeHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.uiButton1.ForePressColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(131)))), ((int)(((byte)(229)))));
            this.uiButton1.ForeSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(131)))), ((int)(((byte)(229)))));
            this.uiButton1.Location = new System.Drawing.Point(30, 50);
            this.uiButton1.Name = "uiButton1";
            this.uiButton1.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(219)))), ((int)(((byte)(227)))));
            this.uiButton1.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(222)))), ((int)(((byte)(255)))));
            this.uiButton1.ShowFocusLine = true;
            this.uiButton1.Size = new System.Drawing.Size(100, 35);
            this.uiButton1.Style = Sunny.UI.UIStyle.White;
            this.uiButton1.StyleCustomMode = true;
            this.uiButton1.TabIndex = 0;
            this.uiButton1.Text = "White";
            this.uiButton1.TipsText = "1";
            this.uiToolTip1.SetToolTip(this.uiButton1, "White");
            // 
            // uiButton2
            // 
            this.uiButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiButton2.ForeSelectedColor = System.Drawing.Color.Empty;
            this.uiButton2.Location = new System.Drawing.Point(144, 50);
            this.uiButton2.Name = "uiButton2";
            this.uiButton2.RectSelectedColor = System.Drawing.Color.Empty;
            this.uiButton2.ShowFocusLine = true;
            this.uiButton2.Size = new System.Drawing.Size(100, 35);
            this.uiButton2.StyleCustomMode = true;
            this.uiButton2.TabIndex = 1;
            this.uiButton2.Text = "Blue";
            this.uiToolTip1.SetToolTip(this.uiButton2, "Blue");
            // 
            // uiButton3
            // 
            this.uiButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(190)))), ((int)(((byte)(40)))));
            this.uiButton3.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(202)))), ((int)(((byte)(81)))));
            this.uiButton3.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(168)))), ((int)(((byte)(35)))));
            this.uiButton3.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(168)))), ((int)(((byte)(35)))));
            this.uiButton3.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiButton3.Location = new System.Drawing.Point(258, 50);
            this.uiButton3.Name = "uiButton3";
            this.uiButton3.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(190)))), ((int)(((byte)(40)))));
            this.uiButton3.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(202)))), ((int)(((byte)(81)))));
            this.uiButton3.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(168)))), ((int)(((byte)(35)))));
            this.uiButton3.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(168)))), ((int)(((byte)(35)))));
            this.uiButton3.ShowFocusLine = true;
            this.uiButton3.Size = new System.Drawing.Size(100, 35);
            this.uiButton3.Style = Sunny.UI.UIStyle.Green;
            this.uiButton3.StyleCustomMode = true;
            this.uiButton3.TabIndex = 2;
            this.uiButton3.Text = "Green";
            // 
            // uiButton4
            // 
            this.uiButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton4.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(127)))), ((int)(((byte)(128)))));
            this.uiButton4.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(87)))), ((int)(((byte)(89)))));
            this.uiButton4.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(87)))), ((int)(((byte)(89)))));
            this.uiButton4.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiButton4.Location = new System.Drawing.Point(600, 50);
            this.uiButton4.Name = "uiButton4";
            this.uiButton4.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton4.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(127)))), ((int)(((byte)(128)))));
            this.uiButton4.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(87)))), ((int)(((byte)(89)))));
            this.uiButton4.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(87)))), ((int)(((byte)(89)))));
            this.uiButton4.ShowFocusLine = true;
            this.uiButton4.Size = new System.Drawing.Size(100, 35);
            this.uiButton4.Style = Sunny.UI.UIStyle.Red;
            this.uiButton4.StyleCustomMode = true;
            this.uiButton4.TabIndex = 5;
            this.uiButton4.Text = "Red";
            // 
            // uiButton5
            // 
            this.uiButton5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(155)))), ((int)(((byte)(40)))));
            this.uiButton5.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(174)))), ((int)(((byte)(86)))));
            this.uiButton5.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(137)))), ((int)(((byte)(43)))));
            this.uiButton5.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(137)))), ((int)(((byte)(43)))));
            this.uiButton5.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiButton5.Location = new System.Drawing.Point(486, 50);
            this.uiButton5.Name = "uiButton5";
            this.uiButton5.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(155)))), ((int)(((byte)(40)))));
            this.uiButton5.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(174)))), ((int)(((byte)(86)))));
            this.uiButton5.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(137)))), ((int)(((byte)(43)))));
            this.uiButton5.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(137)))), ((int)(((byte)(43)))));
            this.uiButton5.ShowFocusLine = true;
            this.uiButton5.Size = new System.Drawing.Size(100, 35);
            this.uiButton5.Style = Sunny.UI.UIStyle.Orange;
            this.uiButton5.StyleCustomMode = true;
            this.uiButton5.TabIndex = 4;
            this.uiButton5.Text = "Orange";
            // 
            // uiButton6
            // 
            this.uiButton6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(140)))), ((int)(((byte)(140)))));
            this.uiButton6.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(160)))), ((int)(((byte)(165)))));
            this.uiButton6.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(121)))), ((int)(((byte)(123)))), ((int)(((byte)(129)))));
            this.uiButton6.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(121)))), ((int)(((byte)(123)))), ((int)(((byte)(129)))));
            this.uiButton6.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiButton6.Location = new System.Drawing.Point(372, 50);
            this.uiButton6.Name = "uiButton6";
            this.uiButton6.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(140)))), ((int)(((byte)(140)))));
            this.uiButton6.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(160)))), ((int)(((byte)(165)))));
            this.uiButton6.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(121)))), ((int)(((byte)(123)))), ((int)(((byte)(129)))));
            this.uiButton6.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(121)))), ((int)(((byte)(123)))), ((int)(((byte)(129)))));
            this.uiButton6.ShowFocusLine = true;
            this.uiButton6.Size = new System.Drawing.Size(100, 35);
            this.uiButton6.Style = Sunny.UI.UIStyle.Gray;
            this.uiButton6.StyleCustomMode = true;
            this.uiButton6.TabIndex = 3;
            this.uiButton6.Text = "Gray";
            // 
            // uiButton7
            // 
            this.uiButton7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.uiButton7.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton7.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(87)))), ((int)(((byte)(89)))));
            this.uiButton7.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(87)))), ((int)(((byte)(89)))));
            this.uiButton7.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiButton7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton7.Location = new System.Drawing.Point(600, 100);
            this.uiButton7.Name = "uiButton7";
            this.uiButton7.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton7.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton7.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(87)))), ((int)(((byte)(89)))));
            this.uiButton7.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(87)))), ((int)(((byte)(89)))));
            this.uiButton7.Size = new System.Drawing.Size(100, 35);
            this.uiButton7.Style = Sunny.UI.UIStyle.LightRed;
            this.uiButton7.StyleCustomMode = true;
            this.uiButton7.TabIndex = 11;
            this.uiButton7.Text = "LightRed";
            // 
            // uiButton8
            // 
            this.uiButton8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(245)))), ((int)(((byte)(233)))));
            this.uiButton8.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(155)))), ((int)(((byte)(40)))));
            this.uiButton8.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(137)))), ((int)(((byte)(43)))));
            this.uiButton8.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(137)))), ((int)(((byte)(43)))));
            this.uiButton8.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiButton8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(155)))), ((int)(((byte)(40)))));
            this.uiButton8.Location = new System.Drawing.Point(486, 100);
            this.uiButton8.Name = "uiButton8";
            this.uiButton8.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(155)))), ((int)(((byte)(40)))));
            this.uiButton8.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(155)))), ((int)(((byte)(40)))));
            this.uiButton8.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(137)))), ((int)(((byte)(43)))));
            this.uiButton8.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(137)))), ((int)(((byte)(43)))));
            this.uiButton8.Size = new System.Drawing.Size(100, 35);
            this.uiButton8.Style = Sunny.UI.UIStyle.LightOrange;
            this.uiButton8.StyleCustomMode = true;
            this.uiButton8.TabIndex = 10;
            this.uiButton8.Text = "LightOrange";
            // 
            // uiButton9
            // 
            this.uiButton9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton9.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(244)))));
            this.uiButton9.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(140)))), ((int)(((byte)(140)))));
            this.uiButton9.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(121)))), ((int)(((byte)(123)))), ((int)(((byte)(129)))));
            this.uiButton9.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(121)))), ((int)(((byte)(123)))), ((int)(((byte)(129)))));
            this.uiButton9.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiButton9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(140)))), ((int)(((byte)(140)))));
            this.uiButton9.Location = new System.Drawing.Point(372, 100);
            this.uiButton9.Name = "uiButton9";
            this.uiButton9.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(140)))), ((int)(((byte)(140)))));
            this.uiButton9.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(140)))), ((int)(((byte)(140)))));
            this.uiButton9.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(121)))), ((int)(((byte)(123)))), ((int)(((byte)(129)))));
            this.uiButton9.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(121)))), ((int)(((byte)(123)))), ((int)(((byte)(129)))));
            this.uiButton9.Size = new System.Drawing.Size(100, 35);
            this.uiButton9.Style = Sunny.UI.UIStyle.LightGray;
            this.uiButton9.StyleCustomMode = true;
            this.uiButton9.TabIndex = 9;
            this.uiButton9.Text = "LightGray";
            // 
            // uiButton10
            // 
            this.uiButton10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(248)))), ((int)(((byte)(232)))));
            this.uiButton10.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(190)))), ((int)(((byte)(40)))));
            this.uiButton10.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(168)))), ((int)(((byte)(35)))));
            this.uiButton10.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(168)))), ((int)(((byte)(35)))));
            this.uiButton10.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiButton10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(190)))), ((int)(((byte)(40)))));
            this.uiButton10.Location = new System.Drawing.Point(258, 100);
            this.uiButton10.Name = "uiButton10";
            this.uiButton10.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(190)))), ((int)(((byte)(40)))));
            this.uiButton10.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(190)))), ((int)(((byte)(40)))));
            this.uiButton10.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(168)))), ((int)(((byte)(35)))));
            this.uiButton10.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(168)))), ((int)(((byte)(35)))));
            this.uiButton10.Size = new System.Drawing.Size(100, 35);
            this.uiButton10.Style = Sunny.UI.UIStyle.LightGreen;
            this.uiButton10.StyleCustomMode = true;
            this.uiButton10.TabIndex = 8;
            this.uiButton10.Text = "LightGreen";
            this.uiButton10.Click += new System.EventHandler(this.uiButton10_Click);
            // 
            // uiButton11
            // 
            this.uiButton11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton11.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiButton11.ForeSelectedColor = System.Drawing.Color.Empty;
            this.uiButton11.Location = new System.Drawing.Point(144, 100);
            this.uiButton11.Name = "uiButton11";
            this.uiButton11.RectSelectedColor = System.Drawing.Color.Empty;
            this.uiButton11.Size = new System.Drawing.Size(100, 35);
            this.uiButton11.StyleCustomMode = true;
            this.uiButton11.TabIndex = 7;
            this.uiButton11.Text = "LightBlue";
            // 
            // uiButton12
            // 
            this.uiButton12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton12.FillColor = System.Drawing.Color.White;
            this.uiButton12.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.uiButton12.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.uiButton12.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.uiButton12.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiButton12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(98)))), ((int)(((byte)(102)))));
            this.uiButton12.ForeHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.uiButton12.ForePressColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(131)))), ((int)(((byte)(229)))));
            this.uiButton12.ForeSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(131)))), ((int)(((byte)(229)))));
            this.uiButton12.Location = new System.Drawing.Point(30, 100);
            this.uiButton12.Name = "uiButton12";
            this.uiButton12.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(219)))), ((int)(((byte)(227)))));
            this.uiButton12.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(222)))), ((int)(((byte)(255)))));
            this.uiButton12.Size = new System.Drawing.Size(100, 35);
            this.uiButton12.Style = Sunny.UI.UIStyle.White;
            this.uiButton12.StyleCustomMode = true;
            this.uiButton12.TabIndex = 6;
            this.uiButton12.Text = "White";
            // 
            // uiButton13
            // 
            this.uiButton13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton13.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton13.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(127)))), ((int)(((byte)(128)))));
            this.uiButton13.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(87)))), ((int)(((byte)(89)))));
            this.uiButton13.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(87)))), ((int)(((byte)(89)))));
            this.uiButton13.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiButton13.Location = new System.Drawing.Point(600, 150);
            this.uiButton13.Name = "uiButton13";
            this.uiButton13.Radius = 35;
            this.uiButton13.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton13.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(127)))), ((int)(((byte)(128)))));
            this.uiButton13.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(87)))), ((int)(((byte)(89)))));
            this.uiButton13.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(87)))), ((int)(((byte)(89)))));
            this.uiButton13.Size = new System.Drawing.Size(100, 35);
            this.uiButton13.Style = Sunny.UI.UIStyle.Red;
            this.uiButton13.StyleCustomMode = true;
            this.uiButton13.TabIndex = 17;
            this.uiButton13.Text = "Red";
            // 
            // uiButton14
            // 
            this.uiButton14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(155)))), ((int)(((byte)(40)))));
            this.uiButton14.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(174)))), ((int)(((byte)(86)))));
            this.uiButton14.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(137)))), ((int)(((byte)(43)))));
            this.uiButton14.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(137)))), ((int)(((byte)(43)))));
            this.uiButton14.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiButton14.Location = new System.Drawing.Point(486, 150);
            this.uiButton14.Name = "uiButton14";
            this.uiButton14.Radius = 35;
            this.uiButton14.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(155)))), ((int)(((byte)(40)))));
            this.uiButton14.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(174)))), ((int)(((byte)(86)))));
            this.uiButton14.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(137)))), ((int)(((byte)(43)))));
            this.uiButton14.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(137)))), ((int)(((byte)(43)))));
            this.uiButton14.Size = new System.Drawing.Size(100, 35);
            this.uiButton14.Style = Sunny.UI.UIStyle.Orange;
            this.uiButton14.StyleCustomMode = true;
            this.uiButton14.TabIndex = 16;
            this.uiButton14.Text = "Orange";
            // 
            // uiButton15
            // 
            this.uiButton15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton15.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(140)))), ((int)(((byte)(140)))));
            this.uiButton15.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(160)))), ((int)(((byte)(165)))));
            this.uiButton15.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(121)))), ((int)(((byte)(123)))), ((int)(((byte)(129)))));
            this.uiButton15.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(121)))), ((int)(((byte)(123)))), ((int)(((byte)(129)))));
            this.uiButton15.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiButton15.Location = new System.Drawing.Point(372, 150);
            this.uiButton15.Name = "uiButton15";
            this.uiButton15.Radius = 35;
            this.uiButton15.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(140)))), ((int)(((byte)(140)))));
            this.uiButton15.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(160)))), ((int)(((byte)(165)))));
            this.uiButton15.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(121)))), ((int)(((byte)(123)))), ((int)(((byte)(129)))));
            this.uiButton15.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(121)))), ((int)(((byte)(123)))), ((int)(((byte)(129)))));
            this.uiButton15.Size = new System.Drawing.Size(100, 35);
            this.uiButton15.Style = Sunny.UI.UIStyle.Gray;
            this.uiButton15.StyleCustomMode = true;
            this.uiButton15.TabIndex = 15;
            this.uiButton15.Text = "Gray";
            // 
            // uiButton16
            // 
            this.uiButton16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton16.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(190)))), ((int)(((byte)(40)))));
            this.uiButton16.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(202)))), ((int)(((byte)(81)))));
            this.uiButton16.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(168)))), ((int)(((byte)(35)))));
            this.uiButton16.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(168)))), ((int)(((byte)(35)))));
            this.uiButton16.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiButton16.Location = new System.Drawing.Point(258, 150);
            this.uiButton16.Name = "uiButton16";
            this.uiButton16.Radius = 35;
            this.uiButton16.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(190)))), ((int)(((byte)(40)))));
            this.uiButton16.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(202)))), ((int)(((byte)(81)))));
            this.uiButton16.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(168)))), ((int)(((byte)(35)))));
            this.uiButton16.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(168)))), ((int)(((byte)(35)))));
            this.uiButton16.Size = new System.Drawing.Size(100, 35);
            this.uiButton16.Style = Sunny.UI.UIStyle.Green;
            this.uiButton16.StyleCustomMode = true;
            this.uiButton16.TabIndex = 14;
            this.uiButton16.Text = "Green";
            // 
            // uiButton17
            // 
            this.uiButton17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton17.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiButton17.ForeSelectedColor = System.Drawing.Color.Empty;
            this.uiButton17.Location = new System.Drawing.Point(144, 150);
            this.uiButton17.Name = "uiButton17";
            this.uiButton17.Radius = 35;
            this.uiButton17.RectSelectedColor = System.Drawing.Color.Empty;
            this.uiButton17.Size = new System.Drawing.Size(100, 35);
            this.uiButton17.StyleCustomMode = true;
            this.uiButton17.TabIndex = 13;
            this.uiButton17.Text = "Blue";
            // 
            // uiButton18
            // 
            this.uiButton18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton18.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiButton18.Location = new System.Drawing.Point(30, 150);
            this.uiButton18.Name = "uiButton18";
            this.uiButton18.Radius = 35;
            this.uiButton18.Size = new System.Drawing.Size(100, 35);
            this.uiButton18.TabIndex = 12;
            this.uiButton18.Text = "Round";
            // 
            // uiLine1
            // 
            this.uiLine1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLine1.Location = new System.Drawing.Point(30, 20);
            this.uiLine1.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine1.Name = "uiLine1";
            this.uiLine1.Size = new System.Drawing.Size(670, 20);
            this.uiLine1.TabIndex = 18;
            this.uiLine1.Text = "UIButton";
            this.uiLine1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLine2
            // 
            this.uiLine2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLine2.Location = new System.Drawing.Point(30, 200);
            this.uiLine2.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine2.Name = "uiLine2";
            this.uiLine2.Size = new System.Drawing.Size(670, 16);
            this.uiLine2.TabIndex = 19;
            this.uiLine2.Text = "UISymbolButton";
            this.uiLine2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiSymbolButton3
            // 
            this.uiSymbolButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(190)))), ((int)(((byte)(40)))));
            this.uiSymbolButton3.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(202)))), ((int)(((byte)(81)))));
            this.uiSymbolButton3.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(168)))), ((int)(((byte)(35)))));
            this.uiSymbolButton3.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(168)))), ((int)(((byte)(35)))));
            this.uiSymbolButton3.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiSymbolButton3.Location = new System.Drawing.Point(372, 230);
            this.uiSymbolButton3.Name = "uiSymbolButton3";
            this.uiSymbolButton3.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(190)))), ((int)(((byte)(40)))));
            this.uiSymbolButton3.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(202)))), ((int)(((byte)(81)))));
            this.uiSymbolButton3.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(168)))), ((int)(((byte)(35)))));
            this.uiSymbolButton3.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(168)))), ((int)(((byte)(35)))));
            this.uiSymbolButton3.Size = new System.Drawing.Size(100, 35);
            this.uiSymbolButton3.Style = Sunny.UI.UIStyle.Green;
            this.uiSymbolButton3.StyleCustomMode = true;
            this.uiSymbolButton3.Symbol = 61530;
            this.uiSymbolButton3.TabIndex = 23;
            this.uiSymbolButton3.Text = "Success";
            // 
            // uiSymbolButton4
            // 
            this.uiSymbolButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton4.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiSymbolButton4.ForeSelectedColor = System.Drawing.Color.Empty;
            this.uiSymbolButton4.Location = new System.Drawing.Point(258, 230);
            this.uiSymbolButton4.Name = "uiSymbolButton4";
            this.uiSymbolButton4.RectSelectedColor = System.Drawing.Color.Empty;
            this.uiSymbolButton4.Size = new System.Drawing.Size(100, 35);
            this.uiSymbolButton4.StyleCustomMode = true;
            this.uiSymbolButton4.Symbol = 61529;
            this.uiSymbolButton4.TabIndex = 22;
            this.uiSymbolButton4.Text = "Query";
            // 
            // uiSymbolButton5
            // 
            this.uiSymbolButton5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(155)))), ((int)(((byte)(40)))));
            this.uiSymbolButton5.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(174)))), ((int)(((byte)(86)))));
            this.uiSymbolButton5.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(137)))), ((int)(((byte)(43)))));
            this.uiSymbolButton5.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(137)))), ((int)(((byte)(43)))));
            this.uiSymbolButton5.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiSymbolButton5.Location = new System.Drawing.Point(486, 230);
            this.uiSymbolButton5.Name = "uiSymbolButton5";
            this.uiSymbolButton5.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(155)))), ((int)(((byte)(40)))));
            this.uiSymbolButton5.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(174)))), ((int)(((byte)(86)))));
            this.uiSymbolButton5.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(137)))), ((int)(((byte)(43)))));
            this.uiSymbolButton5.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(137)))), ((int)(((byte)(43)))));
            this.uiSymbolButton5.Size = new System.Drawing.Size(100, 35);
            this.uiSymbolButton5.Style = Sunny.UI.UIStyle.Orange;
            this.uiSymbolButton5.StyleCustomMode = true;
            this.uiSymbolButton5.Symbol = 61553;
            this.uiSymbolButton5.TabIndex = 24;
            this.uiSymbolButton5.Text = "Warn";
            // 
            // uiSymbolButton6
            // 
            this.uiSymbolButton6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiSymbolButton6.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(127)))), ((int)(((byte)(128)))));
            this.uiSymbolButton6.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(87)))), ((int)(((byte)(89)))));
            this.uiSymbolButton6.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(87)))), ((int)(((byte)(89)))));
            this.uiSymbolButton6.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiSymbolButton6.Location = new System.Drawing.Point(600, 230);
            this.uiSymbolButton6.Name = "uiSymbolButton6";
            this.uiSymbolButton6.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiSymbolButton6.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(127)))), ((int)(((byte)(128)))));
            this.uiSymbolButton6.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(87)))), ((int)(((byte)(89)))));
            this.uiSymbolButton6.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(87)))), ((int)(((byte)(89)))));
            this.uiSymbolButton6.Size = new System.Drawing.Size(100, 35);
            this.uiSymbolButton6.Style = Sunny.UI.UIStyle.Red;
            this.uiSymbolButton6.StyleCustomMode = true;
            this.uiSymbolButton6.Symbol = 61532;
            this.uiSymbolButton6.TabIndex = 25;
            this.uiSymbolButton6.Text = "Error";
            // 
            // uiSymbolButton7
            // 
            this.uiSymbolButton7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiSymbolButton7.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(127)))), ((int)(((byte)(128)))));
            this.uiSymbolButton7.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(87)))), ((int)(((byte)(89)))));
            this.uiSymbolButton7.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(87)))), ((int)(((byte)(89)))));
            this.uiSymbolButton7.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiSymbolButton7.IsCircle = true;
            this.uiSymbolButton7.Location = new System.Drawing.Point(235, 280);
            this.uiSymbolButton7.Name = "uiSymbolButton7";
            this.uiSymbolButton7.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiSymbolButton7.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(127)))), ((int)(((byte)(128)))));
            this.uiSymbolButton7.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(87)))), ((int)(((byte)(89)))));
            this.uiSymbolButton7.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(87)))), ((int)(((byte)(89)))));
            this.uiSymbolButton7.Size = new System.Drawing.Size(35, 35);
            this.uiSymbolButton7.Style = Sunny.UI.UIStyle.Red;
            this.uiSymbolButton7.StyleCustomMode = true;
            this.uiSymbolButton7.Symbol = 61809;
            this.uiSymbolButton7.TabIndex = 31;
            // 
            // uiSymbolButton8
            // 
            this.uiSymbolButton8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(155)))), ((int)(((byte)(40)))));
            this.uiSymbolButton8.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(174)))), ((int)(((byte)(86)))));
            this.uiSymbolButton8.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(137)))), ((int)(((byte)(43)))));
            this.uiSymbolButton8.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(137)))), ((int)(((byte)(43)))));
            this.uiSymbolButton8.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiSymbolButton8.IsCircle = true;
            this.uiSymbolButton8.Location = new System.Drawing.Point(194, 280);
            this.uiSymbolButton8.Name = "uiSymbolButton8";
            this.uiSymbolButton8.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(155)))), ((int)(((byte)(40)))));
            this.uiSymbolButton8.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(174)))), ((int)(((byte)(86)))));
            this.uiSymbolButton8.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(137)))), ((int)(((byte)(43)))));
            this.uiSymbolButton8.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(137)))), ((int)(((byte)(43)))));
            this.uiSymbolButton8.Size = new System.Drawing.Size(35, 35);
            this.uiSymbolButton8.Style = Sunny.UI.UIStyle.Orange;
            this.uiSymbolButton8.StyleCustomMode = true;
            this.uiSymbolButton8.Symbol = 61445;
            this.uiSymbolButton8.TabIndex = 30;
            // 
            // uiSymbolButton9
            // 
            this.uiSymbolButton9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton9.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(190)))), ((int)(((byte)(40)))));
            this.uiSymbolButton9.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(202)))), ((int)(((byte)(81)))));
            this.uiSymbolButton9.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(168)))), ((int)(((byte)(35)))));
            this.uiSymbolButton9.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(168)))), ((int)(((byte)(35)))));
            this.uiSymbolButton9.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiSymbolButton9.IsCircle = true;
            this.uiSymbolButton9.Location = new System.Drawing.Point(153, 280);
            this.uiSymbolButton9.Name = "uiSymbolButton9";
            this.uiSymbolButton9.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(190)))), ((int)(((byte)(40)))));
            this.uiSymbolButton9.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(202)))), ((int)(((byte)(81)))));
            this.uiSymbolButton9.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(168)))), ((int)(((byte)(35)))));
            this.uiSymbolButton9.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(168)))), ((int)(((byte)(35)))));
            this.uiSymbolButton9.Size = new System.Drawing.Size(35, 35);
            this.uiSymbolButton9.Style = Sunny.UI.UIStyle.Green;
            this.uiSymbolButton9.StyleCustomMode = true;
            this.uiSymbolButton9.Symbol = 57607;
            this.uiSymbolButton9.TabIndex = 29;
            // 
            // uiSymbolButton10
            // 
            this.uiSymbolButton10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton10.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiSymbolButton10.ForeSelectedColor = System.Drawing.Color.Empty;
            this.uiSymbolButton10.IsCircle = true;
            this.uiSymbolButton10.Location = new System.Drawing.Point(112, 280);
            this.uiSymbolButton10.Name = "uiSymbolButton10";
            this.uiSymbolButton10.RectSelectedColor = System.Drawing.Color.Empty;
            this.uiSymbolButton10.Size = new System.Drawing.Size(35, 35);
            this.uiSymbolButton10.StyleCustomMode = true;
            this.uiSymbolButton10.TabIndex = 28;
            // 
            // uiSymbolButton11
            // 
            this.uiSymbolButton11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton11.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiSymbolButton11.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(127)))), ((int)(((byte)(128)))));
            this.uiSymbolButton11.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(87)))), ((int)(((byte)(89)))));
            this.uiSymbolButton11.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(87)))), ((int)(((byte)(89)))));
            this.uiSymbolButton11.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiSymbolButton11.IsCircle = true;
            this.uiSymbolButton11.Location = new System.Drawing.Point(71, 280);
            this.uiSymbolButton11.Name = "uiSymbolButton11";
            this.uiSymbolButton11.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiSymbolButton11.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(127)))), ((int)(((byte)(128)))));
            this.uiSymbolButton11.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(87)))), ((int)(((byte)(89)))));
            this.uiSymbolButton11.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(87)))), ((int)(((byte)(89)))));
            this.uiSymbolButton11.Size = new System.Drawing.Size(35, 35);
            this.uiSymbolButton11.Style = Sunny.UI.UIStyle.Red;
            this.uiSymbolButton11.StyleCustomMode = true;
            this.uiSymbolButton11.Symbol = 61508;
            this.uiSymbolButton11.TabIndex = 27;
            // 
            // uiSymbolButton12
            // 
            this.uiSymbolButton12.CircleRectWidth = 2;
            this.uiSymbolButton12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton12.FillColor = System.Drawing.Color.White;
            this.uiSymbolButton12.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.uiSymbolButton12.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.uiSymbolButton12.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.uiSymbolButton12.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiSymbolButton12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(98)))), ((int)(((byte)(102)))));
            this.uiSymbolButton12.ForeHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.uiSymbolButton12.ForePressColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(131)))), ((int)(((byte)(229)))));
            this.uiSymbolButton12.ForeSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(131)))), ((int)(((byte)(229)))));
            this.uiSymbolButton12.IsCircle = true;
            this.uiSymbolButton12.Location = new System.Drawing.Point(30, 280);
            this.uiSymbolButton12.Name = "uiSymbolButton12";
            this.uiSymbolButton12.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(219)))), ((int)(((byte)(227)))));
            this.uiSymbolButton12.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(222)))), ((int)(((byte)(255)))));
            this.uiSymbolButton12.Size = new System.Drawing.Size(35, 35);
            this.uiSymbolButton12.Style = Sunny.UI.UIStyle.White;
            this.uiSymbolButton12.StyleCustomMode = true;
            this.uiSymbolButton12.Symbol = 61442;
            this.uiSymbolButton12.TabIndex = 26;
            // 
            // uiLine3
            // 
            this.uiLine3.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLine3.Location = new System.Drawing.Point(30, 330);
            this.uiLine3.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine3.Name = "uiLine3";
            this.uiLine3.Size = new System.Drawing.Size(670, 20);
            this.uiLine3.TabIndex = 32;
            this.uiLine3.Text = "UISymbolButton 按钮组";
            this.uiLine3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiSymbolButton13
            // 
            this.uiSymbolButton13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton13.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiSymbolButton13.Location = new System.Drawing.Point(260, 360);
            this.uiSymbolButton13.Name = "uiSymbolButton13";
            this.uiSymbolButton13.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiSymbolButton13.RectSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)(((System.Windows.Forms.ToolStripStatusLabelBorderSides.Top | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.uiSymbolButton13.Size = new System.Drawing.Size(46, 35);
            this.uiSymbolButton13.Symbol = 61518;
            this.uiSymbolButton13.TabIndex = 38;
            // 
            // uiSymbolButton14
            // 
            this.uiSymbolButton14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton14.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiSymbolButton14.Location = new System.Drawing.Point(214, 360);
            this.uiSymbolButton14.Name = "uiSymbolButton14";
            this.uiSymbolButton14.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiSymbolButton14.RectSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)(((System.Windows.Forms.ToolStripStatusLabelBorderSides.Top | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.uiSymbolButton14.Size = new System.Drawing.Size(46, 35);
            this.uiSymbolButton14.Symbol = 61514;
            this.uiSymbolButton14.TabIndex = 37;
            // 
            // uiSymbolButton15
            // 
            this.uiSymbolButton15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton15.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiSymbolButton15.Location = new System.Drawing.Point(168, 360);
            this.uiSymbolButton15.Name = "uiSymbolButton15";
            this.uiSymbolButton15.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiSymbolButton15.RectSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)(((System.Windows.Forms.ToolStripStatusLabelBorderSides.Top | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.uiSymbolButton15.Size = new System.Drawing.Size(46, 35);
            this.uiSymbolButton15.Symbol = 61513;
            this.uiSymbolButton15.TabIndex = 36;
            // 
            // uiSymbolButton16
            // 
            this.uiSymbolButton16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton16.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiSymbolButton16.Location = new System.Drawing.Point(122, 360);
            this.uiSymbolButton16.Name = "uiSymbolButton16";
            this.uiSymbolButton16.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiSymbolButton16.RectSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)(((System.Windows.Forms.ToolStripStatusLabelBorderSides.Top | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.uiSymbolButton16.Size = new System.Drawing.Size(46, 35);
            this.uiSymbolButton16.Symbol = 61517;
            this.uiSymbolButton16.TabIndex = 35;
            // 
            // uiSymbolButton17
            // 
            this.uiSymbolButton17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton17.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiSymbolButton17.Location = new System.Drawing.Point(76, 360);
            this.uiSymbolButton17.Name = "uiSymbolButton17";
            this.uiSymbolButton17.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiSymbolButton17.RectSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)(((System.Windows.Forms.ToolStripStatusLabelBorderSides.Top | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.uiSymbolButton17.Size = new System.Drawing.Size(46, 35);
            this.uiSymbolButton17.Symbol = 61516;
            this.uiSymbolButton17.TabIndex = 34;
            // 
            // uiSymbolButton18
            // 
            this.uiSymbolButton18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton18.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiSymbolButton18.Location = new System.Drawing.Point(30, 360);
            this.uiSymbolButton18.Name = "uiSymbolButton18";
            this.uiSymbolButton18.RadiusSides = ((Sunny.UI.UICornerRadiusSides)((Sunny.UI.UICornerRadiusSides.LeftTop | Sunny.UI.UICornerRadiusSides.LeftBottom)));
            this.uiSymbolButton18.Size = new System.Drawing.Size(46, 35);
            this.uiSymbolButton18.Symbol = 61515;
            this.uiSymbolButton18.TabIndex = 33;
            // 
            // uiSymbolButton19
            // 
            this.uiSymbolButton19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton19.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiSymbolButton19.Location = new System.Drawing.Point(516, 360);
            this.uiSymbolButton19.Name = "uiSymbolButton19";
            this.uiSymbolButton19.RadiusSides = ((Sunny.UI.UICornerRadiusSides)((Sunny.UI.UICornerRadiusSides.LeftTop | Sunny.UI.UICornerRadiusSides.LeftBottom)));
            this.uiSymbolButton19.Size = new System.Drawing.Size(46, 35);
            this.uiSymbolButton19.Symbol = 61543;
            this.uiSymbolButton19.TabIndex = 41;
            // 
            // uiSymbolButton20
            // 
            this.uiSymbolButton20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton20.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiSymbolButton20.Location = new System.Drawing.Point(352, 360);
            this.uiSymbolButton20.Name = "uiSymbolButton20";
            this.uiSymbolButton20.RadiusSides = ((Sunny.UI.UICornerRadiusSides)((Sunny.UI.UICornerRadiusSides.RightTop | Sunny.UI.UICornerRadiusSides.RightBottom)));
            this.uiSymbolButton20.RectSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)(((System.Windows.Forms.ToolStripStatusLabelBorderSides.Top | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.uiSymbolButton20.Size = new System.Drawing.Size(46, 35);
            this.uiSymbolButton20.Symbol = 61522;
            this.uiSymbolButton20.TabIndex = 40;
            // 
            // uiSymbolButton21
            // 
            this.uiSymbolButton21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton21.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiSymbolButton21.Location = new System.Drawing.Point(306, 360);
            this.uiSymbolButton21.Name = "uiSymbolButton21";
            this.uiSymbolButton21.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiSymbolButton21.RectSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)(((System.Windows.Forms.ToolStripStatusLabelBorderSides.Top | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.uiSymbolButton21.Size = new System.Drawing.Size(46, 35);
            this.uiSymbolButton21.Symbol = 61520;
            this.uiSymbolButton21.TabIndex = 39;
            // 
            // uiSymbolButton22
            // 
            this.uiSymbolButton22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton22.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiSymbolButton22.Location = new System.Drawing.Point(562, 360);
            this.uiSymbolButton22.Name = "uiSymbolButton22";
            this.uiSymbolButton22.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiSymbolButton22.RectSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)(((System.Windows.Forms.ToolStripStatusLabelBorderSides.Top | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.uiSymbolButton22.Size = new System.Drawing.Size(46, 35);
            this.uiSymbolButton22.Symbol = 61508;
            this.uiSymbolButton22.TabIndex = 42;
            // 
            // uiSymbolButton23
            // 
            this.uiSymbolButton23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton23.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiSymbolButton23.Location = new System.Drawing.Point(608, 360);
            this.uiSymbolButton23.Name = "uiSymbolButton23";
            this.uiSymbolButton23.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiSymbolButton23.RectSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)(((System.Windows.Forms.ToolStripStatusLabelBorderSides.Top | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.uiSymbolButton23.Size = new System.Drawing.Size(46, 35);
            this.uiSymbolButton23.Symbol = 61544;
            this.uiSymbolButton23.TabIndex = 43;
            // 
            // uiSymbolButton24
            // 
            this.uiSymbolButton24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton24.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiSymbolButton24.Location = new System.Drawing.Point(654, 360);
            this.uiSymbolButton24.Name = "uiSymbolButton24";
            this.uiSymbolButton24.RadiusSides = ((Sunny.UI.UICornerRadiusSides)((Sunny.UI.UICornerRadiusSides.RightTop | Sunny.UI.UICornerRadiusSides.RightBottom)));
            this.uiSymbolButton24.RectSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)(((System.Windows.Forms.ToolStripStatusLabelBorderSides.Top | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.uiSymbolButton24.Size = new System.Drawing.Size(46, 35);
            this.uiSymbolButton24.Symbol = 61473;
            this.uiSymbolButton24.TabIndex = 44;
            // 
            // uiSwitch1
            // 
            this.uiSwitch1.Active = true;
            this.uiSwitch1.ActiveText = "On";
            this.uiSwitch1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiSwitch1.InActiveText = "Off";
            this.uiSwitch1.Location = new System.Drawing.Point(30, 441);
            this.uiSwitch1.Name = "uiSwitch1";
            this.uiSwitch1.Size = new System.Drawing.Size(75, 29);
            this.uiSwitch1.TabIndex = 45;
            this.uiSwitch1.Text = "uiSwitch1";
            // 
            // uiLine4
            // 
            this.uiLine4.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLine4.Location = new System.Drawing.Point(30, 412);
            this.uiLine4.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine4.Name = "uiLine4";
            this.uiLine4.Size = new System.Drawing.Size(312, 20);
            this.uiLine4.TabIndex = 46;
            this.uiLine4.Text = "UISwitch";
            this.uiLine4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiSwitch2
            // 
            this.uiSwitch2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiSwitch2.Location = new System.Drawing.Point(112, 441);
            this.uiSwitch2.Name = "uiSwitch2";
            this.uiSwitch2.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.uiSwitch2.Size = new System.Drawing.Size(75, 29);
            this.uiSwitch2.TabIndex = 47;
            this.uiSwitch2.Text = "uiSwitch2";
            // 
            // uiLine5
            // 
            this.uiLine5.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLine5.Location = new System.Drawing.Point(388, 412);
            this.uiLine5.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine5.Name = "uiLine5";
            this.uiLine5.Size = new System.Drawing.Size(312, 20);
            this.uiLine5.TabIndex = 48;
            this.uiLine5.Text = "UIImageButton";
            this.uiLine5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiToolTip1
            // 
            this.uiToolTip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(54)))));
            this.uiToolTip1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiToolTip1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(239)))));
            this.uiToolTip1.OwnerDraw = true;
            // 
            // uiSymbolButton1
            // 
            this.uiSymbolButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiSymbolButton1.ForeSelectedColor = System.Drawing.Color.Empty;
            this.uiSymbolButton1.Location = new System.Drawing.Point(30, 230);
            this.uiSymbolButton1.Name = "uiSymbolButton1";
            this.uiSymbolButton1.RectSelectedColor = System.Drawing.Color.Empty;
            this.uiSymbolButton1.Size = new System.Drawing.Size(100, 35);
            this.uiSymbolButton1.StyleCustomMode = true;
            this.uiSymbolButton1.TabIndex = 20;
            this.uiSymbolButton1.Text = "OK";
            // 
            // uiSymbolButton2
            // 
            this.uiSymbolButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiSymbolButton2.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(127)))), ((int)(((byte)(128)))));
            this.uiSymbolButton2.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(87)))), ((int)(((byte)(89)))));
            this.uiSymbolButton2.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(87)))), ((int)(((byte)(89)))));
            this.uiSymbolButton2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiSymbolButton2.Location = new System.Drawing.Point(144, 230);
            this.uiSymbolButton2.Name = "uiSymbolButton2";
            this.uiSymbolButton2.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiSymbolButton2.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(127)))), ((int)(((byte)(128)))));
            this.uiSymbolButton2.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(87)))), ((int)(((byte)(89)))));
            this.uiSymbolButton2.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(87)))), ((int)(((byte)(89)))));
            this.uiSymbolButton2.Size = new System.Drawing.Size(100, 35);
            this.uiSymbolButton2.Style = Sunny.UI.UIStyle.Red;
            this.uiSymbolButton2.StyleCustomMode = true;
            this.uiSymbolButton2.Symbol = 61453;
            this.uiSymbolButton2.TabIndex = 21;
            this.uiSymbolButton2.Text = "Cancel";
            // 
            // uiSymbolButton25
            // 
            this.uiSymbolButton25.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton25.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.uiSymbolButton25.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.uiSymbolButton25.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiSymbolButton25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.uiSymbolButton25.Image = global::Sunny.UI.Demo.Properties.Resources.relationship;
            this.uiSymbolButton25.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.uiSymbolButton25.Location = new System.Drawing.Point(600, 280);
            this.uiSymbolButton25.Name = "uiSymbolButton25";
            this.uiSymbolButton25.Padding = new System.Windows.Forms.Padding(10, 0, 5, 0);
            this.uiSymbolButton25.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.uiSymbolButton25.Size = new System.Drawing.Size(100, 35);
            this.uiSymbolButton25.Style = Sunny.UI.UIStyle.LightBlue;
            this.uiSymbolButton25.StyleCustomMode = true;
            this.uiSymbolButton25.Symbol = 61453;
            this.uiSymbolButton25.TabIndex = 55;
            this.uiSymbolButton25.Text = "Link";
            this.uiSymbolButton25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiImageButton4
            // 
            this.uiImageButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiImageButton4.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiImageButton4.ForeColor = System.Drawing.Color.Red;
            this.uiImageButton4.Image = global::Sunny.UI.Demo.Properties.Resources.dashboard0;
            this.uiImageButton4.ImageHover = global::Sunny.UI.Demo.Properties.Resources.dashboard;
            this.uiImageButton4.ImageOffset = new System.Drawing.Point(12, 5);
            this.uiImageButton4.ImagePress = global::Sunny.UI.Demo.Properties.Resources.dashboard0;
            this.uiImageButton4.Location = new System.Drawing.Point(630, 435);
            this.uiImageButton4.Name = "uiImageButton4";
            this.uiImageButton4.Size = new System.Drawing.Size(70, 61);
            this.uiImageButton4.TabIndex = 52;
            this.uiImageButton4.TabStop = false;
            this.uiImageButton4.Text = "Home";
            this.uiImageButton4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // uiImageButton3
            // 
            this.uiImageButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiImageButton3.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiImageButton3.Image = global::Sunny.UI.Demo.Properties.Resources.save0;
            this.uiImageButton3.ImageHover = global::Sunny.UI.Demo.Properties.Resources.save;
            this.uiImageButton3.ImagePress = global::Sunny.UI.Demo.Properties.Resources.save0;
            this.uiImageButton3.Location = new System.Drawing.Point(546, 438);
            this.uiImageButton3.Name = "uiImageButton3";
            this.uiImageButton3.Size = new System.Drawing.Size(43, 35);
            this.uiImageButton3.TabIndex = 51;
            this.uiImageButton3.TabStop = false;
            this.uiImageButton3.Text = null;
            // 
            // uiImageButton2
            // 
            this.uiImageButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiImageButton2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiImageButton2.Image = global::Sunny.UI.Demo.Properties.Resources.relationship0;
            this.uiImageButton2.ImageHover = global::Sunny.UI.Demo.Properties.Resources.relationship;
            this.uiImageButton2.ImagePress = global::Sunny.UI.Demo.Properties.Resources.relationship0;
            this.uiImageButton2.Location = new System.Drawing.Point(495, 438);
            this.uiImageButton2.Name = "uiImageButton2";
            this.uiImageButton2.Size = new System.Drawing.Size(43, 35);
            this.uiImageButton2.TabIndex = 50;
            this.uiImageButton2.TabStop = false;
            this.uiImageButton2.Text = null;
            // 
            // uiImageButton1
            // 
            this.uiImageButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiImageButton1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiImageButton1.Image = global::Sunny.UI.Demo.Properties.Resources.dashboard0;
            this.uiImageButton1.ImageHover = global::Sunny.UI.Demo.Properties.Resources.dashboard;
            this.uiImageButton1.ImagePress = global::Sunny.UI.Demo.Properties.Resources.dashboard0;
            this.uiImageButton1.Location = new System.Drawing.Point(395, 438);
            this.uiImageButton1.Name = "uiImageButton1";
            this.uiImageButton1.Size = new System.Drawing.Size(94, 35);
            this.uiImageButton1.TabIndex = 49;
            this.uiImageButton1.TabStop = false;
            this.uiImageButton1.Text = "Home";
            this.uiImageButton1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiSymbolButton26
            // 
            this.uiSymbolButton26.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiSymbolButton26.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.uiSymbolButton26.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.uiSymbolButton26.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiSymbolButton26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.uiSymbolButton26.Image = global::Sunny.UI.Demo.Properties.Resources.save;
            this.uiSymbolButton26.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiSymbolButton26.Location = new System.Drawing.Point(486, 280);
            this.uiSymbolButton26.Name = "uiSymbolButton26";
            this.uiSymbolButton26.Padding = new System.Windows.Forms.Padding(5, 0, 10, 0);
            this.uiSymbolButton26.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.uiSymbolButton26.Size = new System.Drawing.Size(100, 35);
            this.uiSymbolButton26.Style = Sunny.UI.UIStyle.LightBlue;
            this.uiSymbolButton26.StyleCustomMode = true;
            this.uiSymbolButton26.Symbol = 61530;
            this.uiSymbolButton26.TabIndex = 56;
            this.uiSymbolButton26.Text = "Save";
            this.uiSymbolButton26.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // FButton
            // 
            this.AlwaysOpen = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 534);
            this.Name = "FButton";
            this.Symbol = 61640;
            this.Text = "Button";
            this.PagePanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.uiImageButton4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiImageButton3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiImageButton2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uiImageButton1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private UIButton uiButton13;
        private UIButton uiButton14;
        private UIButton uiButton15;
        private UIButton uiButton16;
        private UIButton uiButton17;
        private UIButton uiButton18;
        private UIButton uiButton7;
        private UIButton uiButton8;
        private UIButton uiButton9;
        private UIButton uiButton10;
        private UIButton uiButton11;
        private UIButton uiButton12;
        private UIButton uiButton4;
        private UIButton uiButton5;
        private UIButton uiButton6;
        private UIButton uiButton3;
        private UIButton uiButton2;
        private UIButton uiButton1;
        private UILine uiLine1;
        private UILine uiLine2;
        private UISymbolButton uiSymbolButton3;
        private UISymbolButton uiSymbolButton4;
        private UISymbolButton uiSymbolButton6;
        private UISymbolButton uiSymbolButton5;
        private UISymbolButton uiSymbolButton7;
        private UISymbolButton uiSymbolButton8;
        private UISymbolButton uiSymbolButton9;
        private UISymbolButton uiSymbolButton10;
        private UISymbolButton uiSymbolButton11;
        private UISymbolButton uiSymbolButton12;
        private UISymbolButton uiSymbolButton19;
        private UISymbolButton uiSymbolButton20;
        private UISymbolButton uiSymbolButton21;
        private UISymbolButton uiSymbolButton13;
        private UISymbolButton uiSymbolButton14;
        private UISymbolButton uiSymbolButton15;
        private UISymbolButton uiSymbolButton16;
        private UISymbolButton uiSymbolButton17;
        private UISymbolButton uiSymbolButton18;
        private UILine uiLine3;
        private UISymbolButton uiSymbolButton24;
        private UISymbolButton uiSymbolButton23;
        private UISymbolButton uiSymbolButton22;
        private UISwitch uiSwitch2;
        private UILine uiLine4;
        private UISwitch uiSwitch1;
        private UILine uiLine5;
        private UIImageButton uiImageButton3;
        private UIImageButton uiImageButton2;
        private UIImageButton uiImageButton1;
        private UIImageButton uiImageButton4;
        private UIToolTip uiToolTip1;
        private UISymbolButton uiSymbolButton25;
        private UISymbolButton uiSymbolButton2;
        private UISymbolButton uiSymbolButton1;
        private UISymbolButton uiSymbolButton26;
    }
}