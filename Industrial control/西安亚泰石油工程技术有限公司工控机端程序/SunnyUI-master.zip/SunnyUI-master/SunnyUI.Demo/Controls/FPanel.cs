﻿namespace Sunny.UI.Demo
{
    public partial class FPanel : UITitlePage
    {
        public FPanel()
        {
            InitializeComponent();
        }
    }
}