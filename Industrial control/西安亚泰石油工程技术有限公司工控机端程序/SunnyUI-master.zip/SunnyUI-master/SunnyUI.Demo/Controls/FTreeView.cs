﻿namespace Sunny.UI.Demo
{
    public partial class FTreeView : UITitlePage
    {
        public FTreeView()
        {
            InitializeComponent();
        }
    }
}
