﻿namespace Sunny.UI.Demo
{
    public partial class FTitlePage2 : UITitlePage
    {
        public FTitlePage2()
        {
            InitializeComponent();
        }
    }
}