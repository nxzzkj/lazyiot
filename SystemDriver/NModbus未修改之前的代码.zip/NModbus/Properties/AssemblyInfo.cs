﻿using System;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Modbus 驱动")]
[assembly: AssemblyProduct("Modbus Driver")]
[assembly: AssemblyCompany("宁夏众智科技有限公司")]
[assembly: AssemblyCopyright("Copyright © 2020 宁夏众智科技有限公司")]
[assembly: AssemblyDescription("宁夏众智科技有限公司开发的通用Modbus驱动")]

[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: NeutralResourcesLanguage("en-US")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("3.0.0-dev")]
[assembly: Guid("04FDFA55-8A1F-4EEC-B62A-F5A4D43274C1")]

